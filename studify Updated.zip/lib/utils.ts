import { useState, useEffect } from 'react';
import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { Event } from "./types"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function calculateDynamicPrice(event: Event): { currentPrice: number; surgeAmount: number; isEarlyBird: boolean } {
  const basePrice = event.basePrice ?? event.price;
  const maxPrice = event.maxPrice ?? event.price;
  const capacity = event.capacity ?? 100;
  const sold = event.ticketsSold ?? 0;
  
  // Parse date to get days until event
  // Format is usually "April 30, 2026 • 18:00"
  const datePart = event.date.split(' • ')[0];
  const eventDate = new Date(datePart);
  const today = new Date();
  const diffTime = eventDate.getTime() - today.getTime();
  const daysUntilEvent = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));

  const demandRatio = sold / capacity;

  if (demandRatio <= 0.7 || daysUntilEvent > 7) {
    return { currentPrice: basePrice, surgeAmount: 0, isEarlyBird: true };
  }

  const SURGE_DAYS_THRESHOLD = 7;
  const demandFactor = (demandRatio - 0.7) / 0.3; // 0 to 1
  const timeFactor = (SURGE_DAYS_THRESHOLD - daysUntilEvent) / SURGE_DAYS_THRESHOLD; // 0 to 1

  const surgeMultiplier = demandFactor * timeFactor;
  const calculatedPrice = basePrice + (maxPrice - basePrice) * surgeMultiplier;
  const finalPrice = Number(calculatedPrice.toFixed(2));

  return {
    currentPrice: finalPrice,
    surgeAmount: Number((finalPrice - basePrice).toFixed(2)),
    isEarlyBird: false
  };
}

export function useDynamicPrice(event: Event | null) {
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    const timeout = setTimeout(() => setIsMounted(true), 0);
    return () => clearTimeout(timeout);
  }, []);

  if (!isMounted || !event) {
    return {
      currentPrice: event?.basePrice ?? event?.price ?? 0,
      surgeAmount: 0,
      isEarlyBird: false
    };
  }

  return calculateDynamicPrice(event);
}
