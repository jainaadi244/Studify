import React, { useState } from 'react';
import { useApp } from '@/lib/AppContext';
import { User, MapPin, Lock, CreditCard, Home, Camera, Plus, CheckCircle2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export function Profile() {
  const { t, userEmail, userName, showToast } = useApp();
  const [saved, setSaved] = useState(false);
  
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  
  const [cards, setCards] = useState([
    { id: '1', type: 'VISA', last4: '4242', exp: '12/28' }
  ]);
  
  const [addresses, setAddresses] = useState([
    { id: '1', name: 'Koti', street: 'Yliopistonkatu 1 A 2', city: '28100 Pori' }
  ]);

  // Add Card Modal State
  const [isAddCardModalOpen, setIsAddCardModalOpen] = useState(false);
  const [newCardNumber, setNewCardNumber] = useState('');
  const [newCardExpiry, setNewCardExpiry] = useState('');
  const [newCardCvv, setNewCardCvv] = useState('');
  const [newCardName, setNewCardName] = useState('');

  // Add Address Modal State
  const [isAddAddressModalOpen, setIsAddAddressModalOpen] = useState(false);
  const [newAddressName, setNewAddressName] = useState('');
  const [newAddressStreet, setNewAddressStreet] = useState('');
  const [newAddressCity, setNewAddressCity] = useState('');
  const [newAddressPostal, setNewAddressPostal] = useState('');
  const [newAddressCountry, setNewAddressCountry] = useState('');

  const getCardType = (number: string) => {
    const cleanNumber = number.replace(/\D/g, '');
    if (cleanNumber.startsWith('4')) return 'VISA';
    if (/^5[1-5]/.test(cleanNumber)) return 'MC';
    if (/^3[47]/.test(cleanNumber)) return 'AMEX';
    return 'CARD';
  };

  const handleSaveCard = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCardNumber || !newCardExpiry || !newCardCvv || !newCardName) {
      showToast('Please fill all card details');
      return;
    }
    const cardType = getCardType(newCardNumber);
    const last4 = newCardNumber.replace(/\D/g, '').slice(-4) || '****';
    
    setCards([...cards, { id: Math.random().toString(), type: cardType, last4, exp: newCardExpiry }]);
    showToast('Card added successfully');
    setIsAddCardModalOpen(false);
    setNewCardNumber('');
    setNewCardExpiry('');
    setNewCardCvv('');
    setNewCardName('');
  };

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAddressName || !newAddressStreet || !newAddressCity || !newAddressPostal || !newAddressCountry) {
      showToast('Please fill all address details');
      return;
    }
    
    setAddresses([...addresses, { 
      id: Math.random().toString(), 
      name: newAddressName, 
      street: newAddressStreet, 
      city: `${newAddressPostal} ${newAddressCity}` 
    }]);
    showToast('Address added successfully');
    setIsAddAddressModalOpen(false);
    setNewAddressName('');
    setNewAddressStreet('');
    setNewAddressCity('');
    setNewAddressPostal('');
    setNewAddressCountry('');
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    showToast('Profile saved successfully');
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8 pb-8">
      <div>
        <h2 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white">{t('profile')}</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Left Column: Avatar & Quick Actions */}
        <div className="md:col-span-1 space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 flex flex-col items-center text-center transition-colors">
            <div className="relative w-32 h-32 rounded-full bg-slate-100 dark:bg-slate-800 mb-4 flex items-center justify-center border-4 border-white dark:border-slate-900 shadow-sm">
              <User className="w-12 h-12 text-slate-400" />
              <button onClick={() => showToast('Camera opened')} className="absolute bottom-0 right-0 bg-blue-600 text-white p-2 rounded-full hover:bg-blue-700 transition-colors shadow-sm">
                <Camera className="w-4 h-4" />
              </button>
            </div>
            <h3 className="font-bold text-lg text-slate-900 dark:text-white">{userName}</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">{userEmail}</p>
            <button onClick={() => showToast('Photo upload dialog opened')} className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline">
              {t('uploadPhoto')}
            </button>
          </div>
        </div>

        {/* Right Column: Forms */}
        <div className="md:col-span-2 space-y-6">
          {/* Personal Info */}
          <form onSubmit={handleSave} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 transition-colors space-y-6">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <User className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              {t('personalInfo')}
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">{t('fullName')}</label>
                <input type="text" value={userName} disabled className="w-full px-4 py-2.5 bg-slate-100 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-500 dark:text-slate-400 cursor-not-allowed transition-all" />
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  {t('nameLocked')}
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">{t('email')}</label>
                <input type="email" value={userEmail} disabled className="w-full px-4 py-2.5 bg-slate-100 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 rounded-xl text-slate-500 dark:text-slate-400 cursor-not-allowed transition-all" />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">{t('city')}</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <MapPin className="h-5 w-5 text-slate-400" />
                  </div>
                  <select defaultValue="pori" className="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all appearance-none">
                    <option value="">{t('selectCity')}</option>
                    <option value="helsinki">Helsinki</option>
                    <option value="tampere">Tampere</option>
                    <option value="turku">Turku</option>
                    <option value="oulu">Oulu</option>
                    <option value="pori">Pori</option>
                    <option value="jyvaskyla">Jyväskylä</option>
                    <option value="kuopio">Kuopio</option>
                    <option value="lahti">Lahti</option>
                    <option value="vaasa">Vaasa</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              {saved ? (
                <span className="text-emerald-600 dark:text-emerald-400 text-sm font-medium flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4" />
                  Tallennettu
                </span>
              ) : <div />}
              <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-semibold transition-colors active:scale-95">
                {t('saveChanges')}
              </button>
            </div>
          </form>

          {/* Security */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 transition-colors space-y-6">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Lock className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              {t('changePassword')}
            </h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">{t('currentPassword')}</label>
                <input type="password" value={oldPassword} onChange={(e) => setOldPassword(e.target.value)} placeholder="••••••••" className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all" />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">{t('newPassword')}</label>
                <input type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="••••••••" className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all" />
              </div>
              <button 
                onClick={() => {
                  if (oldPassword && newPassword) {
                    showToast('Password changed successfully');
                    setOldPassword('');
                    setNewPassword('');
                  } else {
                    showToast('Please enter both passwords');
                  }
                }} 
                className="w-full bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-900 dark:text-white py-2.5 rounded-xl font-semibold transition-colors"
              >
                {t('changePassword')}
              </button>
            </div>
          </div>

          {/* Payment Methods */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 transition-colors space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                {t('paymentMethods')}
              </h3>
              <button 
                onClick={() => setIsAddCardModalOpen(true)} 
                className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                {t('addCard')}
              </button>
            </div>
            
            <div className="space-y-3">
              {cards.map(card => (
                <div key={card.id} className="flex items-center justify-between p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/50">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-6 bg-slate-200 dark:bg-slate-700 rounded flex items-center justify-center text-[10px] font-bold text-slate-500 dark:text-slate-400">{card.type}</div>
                    <div>
                      <p className="text-sm font-medium text-slate-900 dark:text-white">•••• •••• •••• {card.last4}</p>
                      <p className="text-xs text-slate-500 dark:text-slate-400">Expires {card.exp}</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => {
                      setCards(cards.filter(c => c.id !== card.id));
                      showToast('Card removed');
                    }} 
                    className="text-sm text-red-500 hover:text-red-600 font-medium"
                  >
                    Poista
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Addresses */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 transition-colors space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Home className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                {t('addresses')}
              </h3>
              <button 
                onClick={() => setIsAddAddressModalOpen(true)} 
                className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                {t('addAddress')}
              </button>
            </div>
            
            <div className="space-y-3">
              {addresses.map(address => (
                <div key={address.id} className="flex items-center justify-between p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/50">
                  <div>
                    <p className="text-sm font-medium text-slate-900 dark:text-white">{address.name}</p>
                    <p className="text-sm text-slate-500 dark:text-slate-400">{address.street}<br/>{address.city}</p>
                  </div>
                  <button 
                    onClick={() => {
                      setAddresses(addresses.filter(a => a.id !== address.id));
                      showToast('Address removed');
                    }} 
                    className="text-sm text-red-500 hover:text-red-600 font-medium"
                  >
                    Poista
                  </button>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* Add Card Modal */}
      <AnimatePresence>
        {isAddCardModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-md overflow-hidden border border-slate-200 dark:border-slate-800"
            >
              <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <h3 className="font-bold text-lg text-slate-900 dark:text-white">Add New Card</h3>
                <button onClick={() => setIsAddCardModalOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                  <X className="w-5 h-5 text-slate-500" />
                </button>
              </div>
              <form onSubmit={handleSaveCard} className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Card Number</label>
                  <div className="relative">
                    <input 
                      type="text" 
                      value={newCardNumber} 
                      onChange={(e) => setNewCardNumber(e.target.value)} 
                      placeholder="0000 0000 0000 0000" 
                      maxLength={19}
                      className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all" 
                    />
                    <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-blue-600 dark:text-blue-400">
                      {newCardNumber ? getCardType(newCardNumber) : ''}
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Expiry Date</label>
                    <input 
                      type="text" 
                      value={newCardExpiry} 
                      onChange={(e) => setNewCardExpiry(e.target.value)} 
                      placeholder="MM/YY" 
                      maxLength={5}
                      className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">CVV</label>
                    <input 
                      type="text" 
                      value={newCardCvv} 
                      onChange={(e) => setNewCardCvv(e.target.value)} 
                      placeholder="123" 
                      maxLength={4}
                      className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all" 
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Name on Card</label>
                  <input 
                    type="text" 
                    value={newCardName} 
                    onChange={(e) => setNewCardName(e.target.value)} 
                    placeholder="John Doe" 
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all" 
                  />
                </div>
                <button type="submit" className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-semibold transition-colors">
                  Save this card
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Address Modal */}
      <AnimatePresence>
        {isAddAddressModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white dark:bg-slate-900 rounded-2xl shadow-xl w-full max-w-md overflow-hidden border border-slate-200 dark:border-slate-800"
            >
              <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <h3 className="font-bold text-lg text-slate-900 dark:text-white">Add New Address</h3>
                <button onClick={() => setIsAddAddressModalOpen(false)} className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                  <X className="w-5 h-5 text-slate-500" />
                </button>
              </div>
              <form onSubmit={handleSaveAddress} className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Address Name (e.g. Home, Work)</label>
                  <input 
                    type="text" 
                    value={newAddressName} 
                    onChange={(e) => setNewAddressName(e.target.value)} 
                    placeholder="Home" 
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all" 
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Street Address</label>
                  <input 
                    type="text" 
                    value={newAddressStreet} 
                    onChange={(e) => setNewAddressStreet(e.target.value)} 
                    placeholder="123 Main St" 
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all" 
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">City</label>
                    <input 
                      type="text" 
                      value={newAddressCity} 
                      onChange={(e) => setNewAddressCity(e.target.value)} 
                      placeholder="Helsinki" 
                      className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all" 
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Postal Code</label>
                    <input 
                      type="text" 
                      value={newAddressPostal} 
                      onChange={(e) => setNewAddressPostal(e.target.value)} 
                      placeholder="00100" 
                      className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all" 
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Country</label>
                  <input 
                    type="text" 
                    value={newAddressCountry} 
                    onChange={(e) => setNewAddressCountry(e.target.value)} 
                    placeholder="Finland" 
                    className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all" 
                  />
                </div>
                <button type="submit" className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-semibold transition-colors">
                  Save this address
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
