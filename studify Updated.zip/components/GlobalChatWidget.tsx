'use client';

import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, X, Send, Phone, MessageSquare, Bot } from 'lucide-react';
import { useApp } from '@/lib/AppContext';
import { motion, AnimatePresence } from 'motion/react';
import { usePathname } from 'next/navigation';

type PortalType = 'student' | 'b2b';

interface Message {
  id: string;
  text: string;
  sender: 'bot' | 'user';
  options?: string[];
}

const CHAT_TRANSLATIONS = {
  en: {
    studentGreeting: "Hi! How can I help you with your student experience today?",
    b2bGreeting: "Hello! How can I assist you with reaching students today?",
    studentOptions: ["Ticket Issue", "App Feedback", "Talk to Human"],
    b2bOptions: ["Sell Tickets", "Advertise to Students", "Analytics & Reports", "Talk to Human"],
    ticketReply: "If you're having trouble with a ticket, please check the 'Tickets' tab. If it's missing, try refreshing the app.",
    feedbackReply: "We love feedback! You can submit detailed feedback in the Settings menu.",
    adReply: "Our advertising programs help you reach thousands of students. Check the 'Start Advertising' page for tiers.",
    sellTicketsReply: "You can easily list your events and sell tickets directly to students. Navigate to the 'My Events' tab to get started.",
    analyticsReply: "We provide detailed analytics on ticket sales and ad performance in your dashboard.",
    partnerReply: "We are always looking for great partners! Please email partners@studify.fi.",
    humanPrompt: "Would you like to connect over a phone call or chat with an agent?",
    humanOptions: ["Phone Call", "Chat with Agent"],
    connectingPhone: "Connecting you to our phone support line...",
    connectingChat: "Connecting you to the next available agent...",
    typeMessage: "Type a message...",
    contactUs: "Contact Us",
    defaultReply: "I'm an automated assistant. To best help you, please select one of the options above, or ask to talk to a human."
  },
  fi: {
    studentGreeting: "Hei! Kuinka voin auttaa sinua opiskelijakokemuksessasi tänään?",
    b2bGreeting: "Hei! Kuinka voin auttaa sinua tavoittamaan opiskelijoita tänään?",
    studentOptions: ["Lippuongelma", "Sovelluksen palaute", "Puhu ihmiselle"],
    b2bOptions: ["Myy lippuja", "Mainosta opiskelijoille", "Analytiikka ja raportit", "Puhu ihmiselle"],
    ticketReply: "Jos sinulla on ongelmia lipun kanssa, tarkista 'Liput'-välilehti. Jos se puuttuu, kokeile päivittää sovellus.",
    feedbackReply: "Rakastamme palautetta! Voit lähettää yksityiskohtaista palautetta Asetukset-valikossa.",
    adReply: "Mainosohjelmamme auttavat sinua tavoittamaan tuhansia opiskelijoita. Katso 'Aloita mainonta' -sivulta tasot.",
    sellTicketsReply: "Voit helposti listata tapahtumasi ja myydä lippuja suoraan opiskelijoille. Siirry 'Omat tapahtumat' -välilehdelle aloittaaksesi.",
    analyticsReply: "Tarjoamme yksityiskohtaista analytiikkaa lipunmyynnistä ja mainosten tehokkuudesta kojelaudallasi.",
    partnerReply: "Etsimme aina hyviä kumppaneita! Lähetä sähköpostia osoitteeseen partners@studify.fi.",
    humanPrompt: "Haluatko yhdistää puhelun vai keskustella agentin kanssa?",
    humanOptions: ["Puhelu", "Keskustele agentin kanssa"],
    connectingPhone: "Yhdistetään puhelintukeen...",
    connectingChat: "Yhdistetään seuraavalle vapaalle agentille...",
    typeMessage: "Kirjoita viesti...",
    contactUs: "Ota yhteyttä",
    defaultReply: "Olen automaattinen avustaja. Valitse jokin yllä olevista vaihtoehdoista tai pyydä puhua ihmiselle."
  },
  sv: {
    studentGreeting: "Hej! Hur kan jag hjälpa dig med din studentupplevelse idag?",
    b2bGreeting: "Hej! Hur kan jag hjälpa dig att nå studenter idag?",
    studentOptions: ["Biljettproblem", "App-feedback", "Prata med en människa"],
    b2bOptions: ["Sälj biljetter", "Annonsera till studenter", "Analys & Rapporter", "Prata med en människa"],
    ticketReply: "Om du har problem med en biljett, kontrollera fliken 'Biljetter'. Om den saknas, försök uppdatera appen.",
    feedbackReply: "Vi älskar feedback! Du kan skicka in detaljerad feedback i menyn Inställningar.",
    adReply: "Våra annonsprogram hjälper dig att nå tusentals studenter. Kolla in sidan 'Börja annonsera' för nivåer.",
    sellTicketsReply: "Du kan enkelt lista dina evenemang och sälja biljetter direkt till studenter. Navigera till fliken 'Mina evenemang' för att komma igång.",
    analyticsReply: "Vi tillhandahåller detaljerad analys av biljettförsäljning och annonsprestanda i din instrumentpanel.",
    partnerReply: "Vi letar alltid efter bra partners! Vänligen maila partners@studify.fi.",
    humanPrompt: "Vill du ansluta via ett telefonsamtal eller chatta med en agent?",
    humanOptions: ["Telefonsamtal", "Chatta med agent"],
    connectingPhone: "Ansluter dig till vår telefonsupport...",
    connectingChat: "Ansluter dig till nästa tillgängliga agent...",
    typeMessage: "Skriv ett meddelande...",
    contactUs: "Kontakta oss",
    defaultReply: "Jag är en automatiserad assistent. Välj ett av alternativen ovan eller be om att få prata med en människa."
  }
};

export function GlobalChatWidget() {
  const { language } = useApp();
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const nextIdRef = useRef(2);

  const portalType: PortalType = pathname?.startsWith('/b2b') ? 'b2b' : 'student';
  const t = CHAT_TRANSLATIONS[language as keyof typeof CHAT_TRANSLATIONS] || CHAT_TRANSLATIONS.en;
  const [prevPortalType, setPrevPortalType] = useState(portalType);

  if (prevPortalType !== portalType) {
    setMessages([]);
    setIsOpen(false);
    setPrevPortalType(portalType);
  }

  // Auto-scroll to bottom
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleOpenChat = () => {
    setIsOpen(true);
    if (messages.length === 0) {
      const initialOptions = portalType === 'student' ? t.studentOptions : t.b2bOptions;
      setMessages([
        {
          id: '1',
          text: portalType === 'student' ? t.studentGreeting : t.b2bGreeting,
          sender: 'bot',
          options: initialOptions
        }
      ]);
    }
  };

  const handleOptionClick = (option: string) => {
    // Add user message
    const userMsg: Message = { id: String(nextIdRef.current++), text: option, sender: 'user' };
    setMessages(prev => [...prev, userMsg]);

    // Determine bot response
    setTimeout(() => {
      let botReplyText = '';
      let nextOptions: string[] | undefined = undefined;

      // Check which option was clicked
      if (option === t.studentOptions[0]) botReplyText = t.ticketReply;
      else if (option === t.studentOptions[1]) botReplyText = t.feedbackReply;
      else if (option === t.b2bOptions[0]) botReplyText = t.sellTicketsReply;
      else if (option === t.b2bOptions[1]) botReplyText = t.adReply;
      else if (option === t.b2bOptions[2]) botReplyText = t.analyticsReply;
      else if (option === t.studentOptions[2] || option === t.b2bOptions[3]) {
        botReplyText = t.humanPrompt;
        nextOptions = t.humanOptions;
      } else if (option === t.humanOptions[0]) {
        botReplyText = t.connectingPhone;
      } else if (option === t.humanOptions[1]) {
        botReplyText = t.connectingChat;
      } else {
        botReplyText = t.defaultReply;
      }

      const botMsg: Message = {
        id: String(nextIdRef.current++),
        text: botReplyText,
        sender: 'bot',
        options: nextOptions
      };
      setMessages(prev => [...prev, botMsg]);
    }, 600);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim()) return;

    const userMsg: Message = { id: String(nextIdRef.current++), text: inputValue, sender: 'user' };
    setMessages(prev => [...prev, userMsg]);
    setInputValue('');

    // Generic bot response for typed messages
    setTimeout(() => {
      const botMsg: Message = {
        id: String(nextIdRef.current++),
        text: t.defaultReply,
        sender: 'bot',
        options: portalType === 'student' ? t.studentOptions : t.b2bOptions
      };
      setMessages(prev => [...prev, botMsg]);
    }, 1000);
  };

  return (
    <>
      {/* Floating Action Button */}
      <button
        onClick={handleOpenChat}
        className={`fixed bottom-24 md:bottom-6 right-4 md:right-6 w-14 h-14 rounded-full shadow-lg flex items-center justify-center text-white transition-transform hover:scale-105 active:scale-95 z-40 ${portalType === 'b2b' ? 'bg-slate-900 dark:bg-slate-100 dark:text-slate-900' : 'bg-blue-600 hover:bg-blue-700'}`}
        aria-label={t.contactUs}
      >
        <MessageCircle className="w-6 h-6" />
      </button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-24 md:bottom-24 right-4 md:right-6 w-[350px] max-w-[calc(100vw-2rem)] h-[500px] max-h-[calc(100vh-8rem)] bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col z-50 overflow-hidden"
          >
            {/* Header */}
            <div className={`p-4 flex items-center justify-between text-white ${portalType === 'b2b' ? 'bg-slate-900 dark:bg-slate-800' : 'bg-blue-600'}`}>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                  <Bot className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold">{t.contactUs}</h3>
                  <p className="text-xs text-white/80">Automated Assistant</p>
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="p-2 hover:bg-white/20 rounded-full transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50 dark:bg-slate-950/50">
              {messages.map((msg) => (
                <div key={msg.id} className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}>
                  <div 
                    className={`max-w-[85%] p-3 rounded-2xl ${
                      msg.sender === 'user' 
                        ? (portalType === 'b2b' ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 rounded-tr-sm' : 'bg-blue-600 text-white rounded-tr-sm')
                        : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-tl-sm'
                    }`}
                  >
                    <p className="text-sm">{msg.text}</p>
                  </div>
                  
                  {/* Options */}
                  {msg.options && (
                    <div className="flex flex-wrap gap-2 mt-2">
                      {msg.options.map((opt, idx) => (
                        <button
                          key={idx}
                          onClick={() => handleOptionClick(opt)}
                          className={`text-xs px-3 py-1.5 rounded-full border transition-colors ${
                            portalType === 'b2b'
                              ? 'border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                              : 'border-blue-200 dark:border-blue-800/50 hover:bg-blue-50 dark:hover:bg-blue-900/20 text-blue-700 dark:text-blue-400'
                          }`}
                        >
                          {opt === t.humanOptions?.[0] && <Phone className="w-3 h-3 inline mr-1.5" />}
                          {opt === t.humanOptions?.[1] && <MessageSquare className="w-3 h-3 inline mr-1.5" />}
                          {opt}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <form onSubmit={handleSendMessage} className="p-3 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder={t.typeMessage}
                className="flex-1 bg-slate-100 dark:bg-slate-800 border-none rounded-full px-4 py-2 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
              <button 
                type="submit"
                disabled={!inputValue.trim()}
                className={`p-2 rounded-full text-white transition-colors disabled:opacity-50 ${
                  portalType === 'b2b' ? 'bg-slate-900 dark:bg-slate-100 dark:text-slate-900' : 'bg-blue-600 hover:bg-blue-700'
                }`}
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
