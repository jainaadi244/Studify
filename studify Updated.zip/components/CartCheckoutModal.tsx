import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle2, Loader2, ShieldCheck, Lock, ChevronLeft } from 'lucide-react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import { PurchasedTicket } from '@/lib/types';
import { CartItem } from '@/lib/AppContext';
import { calculateDynamicPrice } from '@/lib/utils';
import { StripePaymentForm } from '@/components/StripePaymentForm';

const stripePromise = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY 
  ? loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY) 
  : null;

interface CartCheckoutModalProps {
  isOpen: boolean;
  cartItems: CartItem[];
  onClose: () => void;
  onSuccess: (tickets: PurchasedTicket[]) => void;
}

type CheckoutStep = 'summary' | 'payment' | 'processing' | 'success';

export function CartCheckoutModal({ isOpen, cartItems, onClose, onSuccess }: CartCheckoutModalProps) {
  const [step, setStep] = useState<CheckoutStep>('summary');
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [isFetchingSecret, setIsFetchingSecret] = useState(false);

  const subtotal = cartItems.reduce((sum, item) => {
    const { currentPrice } = calculateDynamicPrice(item.event);
    return sum + (currentPrice * item.quantity);
  }, 0);
  const platformFee = 0.00;
  const total = subtotal + platformFee;

  const handleContinueToPayment = async () => {
    if (!stripePromise) {
      setStep('payment');
      return;
    }

    setIsFetchingSecret(true);
    try {
      const res = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: total })
      });
      const data = await res.json();
      if (data.clientSecret) {
        setClientSecret(data.clientSecret);
        setStep('payment');
      } else {
        console.error('Failed to create payment intent:', data.error);
        setStep('payment');
      }
    } catch (e) {
      console.error(e);
      setStep('payment');
    } finally {
      setIsFetchingSecret(false);
    }
  };

  const handlePurchase = () => {
    setStep('processing');
    
    setTimeout(() => {
      setStep('success');
      
      setTimeout(() => {
        const newTickets: PurchasedTicket[] = [];
        cartItems.forEach(item => {
          for (let i = 0; i < item.quantity; i++) {
            newTickets.push({
              id: Math.random().toString(36).substring(2, 10).toUpperCase() + i,
              event: item.event,
              purchaseDate: new Date().toISOString(),
              qrCode: `TICKET-${Math.random().toString(36).substring(2, 10).toUpperCase()}-${item.event.id}-${i}`,
            });
          }
        });
        onSuccess(newTickets);
      }, 1500);
    }, 2000);
  };

  const handleClose = () => {
    if (step !== 'processing') {
      onClose();
      setTimeout(() => {
        setStep('summary');
        setClientSecret(null);
      }, 300);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          key="backdrop"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50"
          onClick={handleClose}
        />
      )}
      {isOpen && (
        <div key="modal-container" className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none">
          <motion.div 
            key="modal-content"
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="bg-white dark:bg-slate-900 rounded-3xl shadow-2xl w-full max-w-md overflow-hidden pointer-events-auto flex flex-col max-h-[90vh]"
          >
          <div className="p-6 border-b border-slate-100 dark:border-slate-800 relative flex items-center justify-center shrink-0">
            {step === 'payment' && (
              <button 
                onClick={() => setStep('summary')}
                className="absolute left-6 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 transition-colors"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
            )}
            <h2 className="text-xl font-bold text-slate-900 dark:text-white text-center">
              {step === 'summary' && 'Order Summary'}
              {step === 'payment' && 'Checkout'}
              {step === 'processing' && 'Processing'}
              {step === 'success' && 'Success'}
            </h2>
            {step !== 'processing' && step !== 'success' && (
              <button 
                onClick={handleClose}
                className="absolute right-6 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 bg-slate-100 dark:bg-slate-800 rounded-full p-1.5 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
          
          {step === 'summary' && (
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="flex flex-col overflow-y-auto"
            >
              <div className="p-6 bg-slate-50 dark:bg-slate-950/50">
                <div className="space-y-4 mb-6">
                  {cartItems.map((item) => {
                    const { currentPrice } = calculateDynamicPrice(item.event);
                    return (
                      <div key={item.event.id} className="flex justify-between items-center text-slate-600 dark:text-slate-400">
                        <div className="flex flex-col">
                          <span className="font-medium text-slate-900 dark:text-white line-clamp-1">{item.event.title}</span>
                          <span className="text-sm">{item.quantity} × €{currentPrice.toFixed(2)}</span>
                        </div>
                        <span className="font-medium text-slate-900 dark:text-white">€{(currentPrice * item.quantity).toFixed(2)}</span>
                      </div>
                    );
                  })}
                </div>

                <div className="space-y-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                  <div className="flex justify-between items-center text-slate-600 dark:text-slate-400">
                    <span>Platform Fee</span>
                    <span className="font-medium text-slate-900 dark:text-white">€{platformFee.toFixed(2)}</span>
                  </div>
                </div>
                
                <div className="mt-6 pt-4 border-t border-slate-200 dark:border-slate-800 flex justify-between items-center">
                  <span className="font-bold text-slate-900 dark:text-white text-lg">Total</span>
                  <span className="font-bold text-2xl text-slate-900 dark:text-white">€{total.toFixed(2)}</span>
                </div>
              </div>

              <div className="p-6 pt-4 shrink-0">
                <button 
                  onClick={handleContinueToPayment}
                  disabled={isFetchingSecret}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-base flex items-center justify-center transition-all active:scale-95 shadow-sm disabled:opacity-50"
                >
                  {isFetchingSecret ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Continue to Payment'}
                </button>
              </div>
            </motion.div>
          )}

          {step === 'payment' && (
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex flex-col flex-1"
            >
              {clientSecret && stripePromise ? (
                <Elements stripe={stripePromise} options={{ clientSecret, appearance: { theme: 'stripe' } }}>
                  <StripePaymentForm amount={total} onSuccess={handlePurchase} />
                </Elements>
              ) : (
                <div className="flex flex-col h-full">
                  <div className="p-6 bg-slate-50 dark:bg-slate-950/50 flex-grow">
                    <div className="flex justify-between items-center mb-6">
                      <span className="text-slate-500 dark:text-slate-400 font-medium">Total to pay</span>
                      <span className="font-bold text-2xl text-slate-900 dark:text-white">€{total.toFixed(2)}</span>
                    </div>
                    <div className="bg-amber-50 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300 p-4 rounded-xl text-sm mb-6 border border-amber-200 dark:border-amber-800/50">
                      <p className="font-bold mb-1">Test Mode Active</p>
                      <p>Stripe keys are not configured. This is a simulated checkout flow.</p>
                    </div>
                  </div>
                  <div className="p-6 pt-4 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
                    <button
                      onClick={handlePurchase}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition-all active:scale-95 shadow-sm"
                    >
                      <Lock className="w-4 h-4" />
                      Simulate Payment
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {step === 'processing' && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-12 flex flex-col items-center justify-center text-center"
            >
              <div className="w-20 h-20 bg-blue-50 dark:bg-blue-900/20 rounded-full flex items-center justify-center mb-6">
                <Loader2 className="w-10 h-10 text-blue-600 dark:text-blue-400 animate-spin" />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">Processing Payment</h3>
              <p className="text-slate-500 dark:text-slate-400">Please do not close this window...</p>
            </motion.div>
          )}

          {step === 'success' && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="p-12 flex flex-col items-center justify-center text-center"
            >
              <div className="w-20 h-20 bg-emerald-50 dark:bg-emerald-900/20 rounded-full flex items-center justify-center mb-6">
                <CheckCircle2 className="w-10 h-10 text-emerald-500" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Payment Successful!</h3>
              <p className="text-slate-500 dark:text-slate-400">Your tickets have been added to your wallet.</p>
            </motion.div>
          )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
