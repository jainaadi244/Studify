import React, { useState } from 'react';
import { Mail, Sparkles, ArrowRight } from 'lucide-react';
import { useApp } from '@/lib/AppContext';

interface ComingSoonViewProps {
  featureName: string;
}

export function ComingSoonView({ featureName }: ComingSoonViewProps) {
  const { showToast } = useApp();
  const [email, setEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      showToast('Thanks for registering! We\'ll keep you updated.');
      setEmail('');
    }
  };

  return (
    <div className="max-w-2xl mx-auto text-center py-16 px-4">
      <div className="w-20 h-20 bg-blue-50 dark:bg-blue-900/20 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-sm border border-blue-100 dark:border-blue-800/50">
        <Sparkles className="w-10 h-10 text-blue-600 dark:text-blue-400" />
      </div>
      
      <h2 className="text-3xl font-bold text-slate-900 dark:text-white mb-4">
        {featureName} is coming in v2!
      </h2>
      
      <p className="text-lg text-slate-600 dark:text-slate-400 mb-8 max-w-lg mx-auto leading-relaxed">
        We are currently focusing purely on building the best ticketing platform. 
        This feature will be available in our upcoming Version 2 release.
      </p>
      
      <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm max-w-md mx-auto">
        <h3 className="font-bold text-slate-900 dark:text-white mb-2 text-lg">Get early access</h3>
        <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">Register your email to get updates when we launch v2.</p>
        
        <form onSubmit={handleSubscribe} className="space-y-3">
          <div className="relative">
            <Mail className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="email" 
              placeholder="Enter your student email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full pl-12 pr-4 py-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-600 dark:text-white transition-all"
            />
          </div>
          <button 
            type="submit"
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            Notify Me
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
