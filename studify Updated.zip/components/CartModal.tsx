import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShoppingCart, Trash2, Plus, Minus } from 'lucide-react';
import Image from 'next/image';
import { useApp, CartItem } from '@/lib/AppContext';
import { useDynamicPrice, calculateDynamicPrice } from '@/lib/utils';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCheckout: () => void;
}

function CartItemRow({ item }: { item: CartItem }) {
  const { removeFromCart, addToCart } = useApp();
  const { currentPrice } = useDynamicPrice(item.event);

  return (
    <div className="flex items-center gap-4 bg-slate-50 dark:bg-slate-800/50 p-4 rounded-2xl border border-slate-100 dark:border-slate-800">
      <div className="relative w-16 h-16 shrink-0">
        <Image src={item.event.image} alt={item.event.title} fill className="object-cover rounded-xl" referrerPolicy="no-referrer" />
      </div>
      <div className="flex-1">
        <h4 className="font-bold text-slate-900 dark:text-white line-clamp-1">{item.event.title}</h4>
        <p className="text-sm text-slate-500 dark:text-slate-400">€{currentPrice.toFixed(2)} each</p>
      </div>
      <div className="flex flex-col items-end gap-2">
        <div className="flex items-center gap-3 bg-white dark:bg-slate-900 rounded-lg p-1 border border-slate-200 dark:border-slate-700 shadow-sm">
          <button 
            onClick={() => item.quantity > 1 ? addToCart(item.event, -1) : removeFromCart(item.event.id)}
            className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 transition-colors"
          >
            <Minus className="w-4 h-4" />
          </button>
          <span className="w-4 text-center font-bold text-slate-900 dark:text-white">{item.quantity}</span>
          <button 
            onClick={() => addToCart(item.event, 1)}
            className="w-8 h-8 flex items-center justify-center rounded-md hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400 transition-colors"
          >
            <Plus className="w-4 h-4" />
          </button>
        </div>
        <button 
          onClick={() => removeFromCart(item.event.id)}
          className="text-xs text-red-500 hover:text-red-600 font-medium flex items-center gap-1"
        >
          <Trash2 className="w-3 h-3" /> Remove
        </button>
      </div>
    </div>
  );
}

export function CartModal({ isOpen, onClose, onCheckout }: CartModalProps) {
  const { cart } = useApp();

  const total = cart.reduce((sum, item) => {
    const { currentPrice } = calculateDynamicPrice(item.event);
    return sum + (currentPrice * item.quantity);
  }, 0);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
        />
        <motion.div
          initial={{ y: '100%' }}
          animate={{ y: 0 }}
          exit={{ y: '100%' }}
          transition={{ type: 'spring', damping: 25, stiffness: 200 }}
          className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
        >
          <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-white dark:bg-slate-900 sticky top-0 z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-50 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
                <ShoppingCart className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              </div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">Your Cart</h2>
            </div>
            <button
              onClick={onClose}
              className="w-10 h-10 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full flex items-center justify-center text-slate-500 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6">
            {cart.length === 0 ? (
              <div className="text-center py-12">
                <ShoppingCart className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-4" />
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">Your cart is empty</h3>
                <p className="text-slate-500 dark:text-slate-400">Add some tickets to your cart to checkout.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {cart.map((item) => (
                  <CartItemRow key={item.event.id} item={item} />
                ))}
              </div>
            )}
          </div>

          {cart.length > 0 && (
            <div className="p-6 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
              <div className="flex justify-between items-center mb-6">
                <span className="text-slate-500 dark:text-slate-400 font-medium">Total</span>
                <span className="font-bold text-2xl text-slate-900 dark:text-white">€{total.toFixed(2)}</span>
              </div>
              <button
                onClick={onCheckout}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition-all active:scale-95 shadow-sm"
              >
                Checkout
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
