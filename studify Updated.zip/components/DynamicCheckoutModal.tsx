'use client';

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle2, Info, Ticket } from 'lucide-react';
import { useApp } from '@/lib/AppContext';

interface DynamicCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  eventName: string;
  basePrice: number;
  maxPrice: number;
  totalCapacity: number;
  ticketsSold: number;
  daysUntilEvent: number;
}

export function DynamicCheckoutModal({
  isOpen,
  onClose,
  eventName,
  basePrice,
  maxPrice,
  totalCapacity,
  ticketsSold,
  daysUntilEvent,
}: DynamicCheckoutModalProps) {
  const { showToast } = useApp();
  const { currentPrice, surgeAmount } = React.useMemo(() => {
    const calculateCurrentPrice = (): number => {
      const demandRatio = ticketsSold / totalCapacity;

      if (demandRatio < 0.5) {
        return basePrice;
      }

      if (demandRatio <= 0.7) {
        return basePrice;
      }

      const SURGE_DAYS_THRESHOLD = 7;
      if (daysUntilEvent > SURGE_DAYS_THRESHOLD) {
        return basePrice;
      }

      const demandFactor = (demandRatio - 0.7) / 0.3;
      const timeFactor = (SURGE_DAYS_THRESHOLD - Math.max(0, daysUntilEvent)) / SURGE_DAYS_THRESHOLD;

      const surgeMultiplier = demandFactor * timeFactor;
      const calculatedPrice = basePrice + (maxPrice - basePrice) * surgeMultiplier;

      return Number(calculatedPrice.toFixed(2));
    };

    const finalPrice = calculateCurrentPrice();
    return {
      currentPrice: finalPrice,
      surgeAmount: Number((finalPrice - basePrice).toFixed(2))
    };
  }, [basePrice, maxPrice, totalCapacity, ticketsSold, daysUntilEvent]);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-md overflow-hidden rounded-2xl bg-slate-900 shadow-2xl ring-1 ring-white/10"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-white/10 px-6 py-4">
              <h2 className="text-lg font-semibold text-white truncate pr-4">
                {eventName}
              </h2>
              <button
                onClick={onClose}
                className="rounded-full p-1 text-slate-400 hover:bg-white/10 hover:text-white transition-colors"
                aria-label="Close modal"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6">
              <div className="mb-6 flex flex-col items-center text-center">
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-blue-500/20 text-blue-400">
                  <Ticket className="h-6 w-6" />
                </div>
                <h3 className="text-sm font-medium text-slate-400 uppercase tracking-wider">
                  Current Price
                </h3>
                <div className="mt-1 flex items-baseline justify-center gap-1">
                  <span className="text-4xl font-bold tracking-tight text-white">
                    €{currentPrice.toFixed(2)}
                  </span>
                </div>
                
                {surgeAmount === 0 && (
                  <div className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-emerald-500/10 px-3 py-1 text-sm font-medium text-emerald-400 ring-1 ring-inset ring-emerald-500/20">
                    <CheckCircle2 className="h-4 w-4" />
                    Early Bird Pricing Active
                  </div>
                )}
              </div>

              {/* Pricing Breakdown */}
              <div className="rounded-xl bg-slate-800/50 p-4 ring-1 ring-white/5">
                <h4 className="mb-3 text-sm font-medium text-slate-300">
                  Pricing Breakdown
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between text-slate-400">
                    <span>Base Ticket</span>
                    <span className="text-slate-300">€{basePrice.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Demand Surge</span>
                    <span className={surgeAmount > 0 ? "text-blue-400 font-medium" : "text-slate-300"}>
                      +€{surgeAmount.toFixed(2)}
                    </span>
                  </div>
                  <div className="my-2 border-t border-white/10" />
                  <div className="flex justify-between font-medium text-white">
                    <span>Total</span>
                    <span>€{currentPrice.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* USP */}
              <div className="mt-4 flex items-start gap-2 rounded-lg bg-blue-500/10 p-3 text-sm text-blue-200 ring-1 ring-blue-500/20">
                <Info className="mt-0.5 h-4 w-4 shrink-0 text-blue-400" />
                <p>
                  <span className="font-semibold text-blue-300">Platform Fee: €0.00</span> (Student Guarantee)
                </p>
              </div>
            </div>

            {/* Footer */}
            <div className="border-t border-white/10 bg-slate-800/50 px-6 py-4">
              <button
                type="button"
                className="w-full rounded-xl bg-blue-600 px-4 py-3 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-blue-600 transition-all active:scale-[0.98]"
                onClick={() => {
                  // Handle payment logic here
                  showToast(`Proceeding to payment for €${currentPrice.toFixed(2)}`);
                  onClose();
                }}
              >
                Proceed to Payment
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
