'use client';

import React, { useState } from 'react';
import { Loader2, Lock, ShieldCheck } from 'lucide-react';
import { PaymentElement, ExpressCheckoutElement, useStripe, useElements } from '@stripe/react-stripe-js';

export function StripePaymentForm({ amount, onSuccess }: { amount: number, onSuccess: () => void }) {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const confirmPayment = async () => {
    if (!stripe || !elements) return;
    setIsProcessing(true);
    setErrorMessage(null);

    const { error, paymentIntent } = await stripe.confirmPayment({
      elements,
      redirect: 'if_required',
    });

    if (error) {
      setErrorMessage(error.message ?? 'An unknown error occurred');
      setIsProcessing(false);
    } else if (paymentIntent && paymentIntent.status === 'succeeded') {
      onSuccess();
    } else {
      setIsProcessing(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await confirmPayment();
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col h-full">
      <div className="p-6 bg-slate-50 dark:bg-slate-950/50 flex-grow">
        <div className="flex justify-between items-center mb-6">
          <span className="text-slate-500 dark:text-slate-400 font-medium">Total to pay</span>
          <span className="font-bold text-2xl text-slate-900 dark:text-white">€{amount.toFixed(2)}</span>
        </div>
        
        <div className="mb-4">
          <ExpressCheckoutElement onConfirm={confirmPayment} />
        </div>
        
        <div className="relative py-4 flex items-center">
          <div className="flex-grow border-t border-slate-200 dark:border-slate-700"></div>
          <span className="flex-shrink-0 mx-4 text-slate-400 text-sm font-medium">or pay with card</span>
          <div className="flex-grow border-t border-slate-200 dark:border-slate-700"></div>
        </div>

        <PaymentElement />
        {errorMessage && <div className="text-red-500 text-sm mt-4 font-medium">{errorMessage}</div>}
      </div>
      <div className="p-6 pt-4 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
        <button
          type="submit"
          disabled={!stripe || isProcessing}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition-all active:scale-95 shadow-sm disabled:opacity-50"
        >
          {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <Lock className="w-4 h-4" />}
          {isProcessing ? 'Processing...' : `Pay €${amount.toFixed(2)}`}
        </button>
        <div className="mt-4 flex items-center justify-center gap-1.5 text-xs text-slate-500 dark:text-slate-400 font-medium">
          <ShieldCheck className="w-4 h-4 text-emerald-500" />
          Secured by Stripe
        </div>
      </div>
    </form>
  );
}
