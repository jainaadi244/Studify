import type {Metadata} from 'next';
import './globals.css'; // Global styles
import { AppProvider } from '@/lib/AppContext';
import { GlobalChatWidget } from '@/components/GlobalChatWidget';

export const metadata: Metadata = {
  title: 'My Google AI Studio App',
  description: 'My Google AI Studio App',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>
        <AppProvider>
          {children}
          <GlobalChatWidget />
        </AppProvider>
      </body>
    </html>
  );
}
