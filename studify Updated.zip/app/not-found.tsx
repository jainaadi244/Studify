import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-slate-50 p-4 text-center dark:bg-slate-950">
      <h2 className="mb-4 text-4xl font-bold text-slate-900 dark:text-white">404 - Page Not Found</h2>
      <p className="mb-8 text-slate-500 dark:text-slate-400">Could not find requested resource</p>
      <Link
        href="/"
        className="rounded-xl bg-blue-600 px-6 py-3 text-sm font-semibold text-white transition-colors hover:bg-blue-700"
      >
        Return Home
      </Link>
    </div>
  );
}
