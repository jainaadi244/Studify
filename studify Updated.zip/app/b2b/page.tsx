'use client';

import React, { useState, useMemo } from 'react';
import { ArrowLeft, Plus, BarChart3, CalendarDays, Megaphone, Users, TrendingUp, DollarSign, Eye, Edit, Trash2, Ticket, Building2, Lock, ScanLine, CheckCircle2, Search, Filter, Play, Pause, MoreHorizontal } from 'lucide-react';
import Link from 'next/link';
import Image from 'next/image';
import { useApp } from '@/lib/AppContext';
import { Event } from '@/lib/types';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, BarChart, Bar, Legend, AreaChart, Area } from 'recharts';

export default function B2BPortal() {
  const { t, events, setEvents, isB2BLoggedIn, setIsB2BLoggedIn, purchasedTickets, setPurchasedTickets, showToast } = useApp();
  const [activeTab, setActiveTab] = useState<'dashboard' | 'events' | 'checkin' | 'ads'>('dashboard');
  const [showCreateEvent, setShowCreateEvent] = useState(false);
  const [editingEventId, setEditingEventId] = useState<string | null>(null);
  
  // Login State
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loginError, setLoginError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Mock login logic
    if (loginEmail && loginPassword) {
      setIsB2BLoggedIn(true);
      setLoginError('');
    } else {
      setLoginError('Please enter both email and password.');
    }
  };

  // New Event Form State
  const [newEvent, setNewEvent] = useState({
    title: '',
    date: '',
    time: '',
    location: '',
    price: '',
    image: '',
    description: '',
    category: '',
    capacity: ''
  });

  // Search and Filter State
  const [eventSearchQuery, setEventSearchQuery] = useState('');
  const [ticketSearchQuery, setTicketSearchQuery] = useState('');
  const [ticketVerificationId, setTicketVerificationId] = useState('');
  
  const [showProgramAdForm, setShowProgramAdForm] = useState(false);
  const [programAd, setProgramAd] = useState({
    name: '',
    description: '',
    price: ''
  });
  
  const [campaigns, setCampaigns] = useState([
    { id: '1', title: 'Wappu Early Bird', status: 'Active', impressions: 12500, clicks: 840, spent: 150.00, budget: 500.00 },
    { id: '2', title: 'Student Discount 20%', status: 'Paused', impressions: 45000, clicks: 3200, spent: 450.00, budget: 450.00 },
    { id: '3', title: 'Hockey Game Promo', status: 'Active', impressions: 8200, clicks: 410, spent: 85.00, budget: 200.00 },
  ]);

  // Mock Data for Charts
  const revenueData = useMemo(() => [
    { name: 'Mon', revenue: 120, tickets: 24 },
    { name: 'Tue', revenue: 300, tickets: 60 },
    { name: 'Wed', revenue: 250, tickets: 50 },
    { name: 'Thu', revenue: 450, tickets: 90 },
    { name: 'Fri', revenue: 700, tickets: 140 },
    { name: 'Sat', revenue: 1200, tickets: 240 },
    { name: 'Sun', revenue: 800, tickets: 160 },
  ], []);

  const ticketSalesData = useMemo(() => events.map(e => ({
    name: e.title.length > 15 ? e.title.substring(0, 15) + '...' : e.title,
    sold: e.ticketsSold || 0,
    remaining: (e.capacity || 100) - (e.ticketsSold || 0),
  })), [events]);

  // Derived State
  const filteredEvents = events.filter(e => e.title.toLowerCase().includes(eventSearchQuery.toLowerCase()) || e.location.toLowerCase().includes(eventSearchQuery.toLowerCase()));
  const filteredTickets = purchasedTickets.filter(t => t.id.toLowerCase().includes(ticketSearchQuery.toLowerCase()) || t.event.title.toLowerCase().includes(ticketSearchQuery.toLowerCase()) || t.qrCode.toLowerCase().includes(ticketSearchQuery.toLowerCase()));
  const checkedInCount = purchasedTickets.filter(t => t.status === 'used').length;

  const handleEditEvent = (event: Event) => {
    // The date is currently in format "March 16, 2026 • 18:00"
    // We need to convert it to "YYYY-MM-DD" for the input type="date"
    const [dateString, timePart] = event.date.split(' • ');
    
    let formattedDate = '';
    if (dateString) {
      try {
        const d = new Date(dateString);
        if (!isNaN(d.getTime())) {
          formattedDate = d.toISOString().split('T')[0];
        }
      } catch (e) {
        console.error("Failed to parse date", e);
      }
    }

    setNewEvent({
      title: event.title,
      date: formattedDate,
      time: timePart || '',
      location: event.location,
      price: event.price.toString(),
      image: event.image,
      description: event.description || '',
      category: event.category || '',
      capacity: event.capacity?.toString() || ''
    });
    setEditingEventId(event.id);
    setShowCreateEvent(true);
  };

  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Format date back to "Month DD, YYYY • HH:MM"
    let displayDate = '';
    if (newEvent.date) {
      try {
        const d = new Date(newEvent.date);
        if (!isNaN(d.getTime())) {
          displayDate = d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
        }
      } catch (e) {
        displayDate = newEvent.date;
      }
    }
    const finalDateString = `${displayDate || newEvent.date} • ${newEvent.time}`;

    if (editingEventId) {
      setEvents(events.map(ev => ev.id === editingEventId ? {
        ...ev,
        title: newEvent.title,
        date: finalDateString,
        location: newEvent.location,
        price: parseFloat(newEvent.price) || 0,
        image: newEvent.image || `https://picsum.photos/seed/${Date.now()}/800/600`,
        description: newEvent.description,
        category: newEvent.category,
        capacity: parseInt(newEvent.capacity) || undefined
      } : ev));
    } else {
      const event: Event = {
        id: Math.random().toString(36).substring(2, 10).toUpperCase(),
        title: newEvent.title,
        date: finalDateString,
        location: newEvent.location,
        price: parseFloat(newEvent.price) || 0,
        image: newEvent.image || `https://picsum.photos/seed/${Date.now()}/800/600`,
        ticketsSold: 0,
        views: 0,
        description: newEvent.description,
        category: newEvent.category,
        capacity: parseInt(newEvent.capacity) || undefined
      };
      setEvents([...events, event]);
    }
    
    setShowCreateEvent(false);
    setEditingEventId(null);
    setNewEvent({ title: '', date: '', time: '', location: '', price: '', image: '', description: '', category: '', capacity: '' });
  };

  const handleCheckIn = (ticketId: string) => {
    setPurchasedTickets(purchasedTickets.map(t => 
      t.id === ticketId ? { ...t, status: 'used' } : t
    ));
  };

  const handleDeleteEvent = (id: string) => {
    setEvents(events.filter(e => e.id !== id));
    showToast('Event deleted successfully');
  };

  const handleVerifyTicket = () => {
    if (!ticketVerificationId) {
      showToast('Please enter a ticket ID');
      return;
    }
    const ticketIndex = purchasedTickets.findIndex(t => t.id.toLowerCase() === ticketVerificationId.toLowerCase());
    if (ticketIndex !== -1) {
      const ticket = purchasedTickets[ticketIndex];
      if (ticket.status === 'used') {
        showToast('Ticket has already been used!');
      } else {
        const newTickets = [...purchasedTickets];
        newTickets[ticketIndex] = { ...ticket, status: 'used' };
        setPurchasedTickets(newTickets);
        showToast('Ticket verified successfully!');
        setTicketVerificationId('');
      }
    } else {
      showToast('Invalid ticket ID');
    }
  };

  const handleToggleCampaignStatus = (id: string) => {
    setCampaigns(campaigns.map(c => c.id === id ? { ...c, status: c.status === 'Active' ? 'Paused' : 'Active' } : c));
    showToast(`Campaign status updated`);
  };

  const handleDeleteCampaign = (id: string) => {
    setCampaigns(campaigns.filter(c => c.id !== id));
    showToast('Campaign deleted');
  };

  const handleCreateProgramAd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!programAd.name || !programAd.price) {
      showToast('Please fill in required fields');
      return;
    }
    
    const newCampaign = {
      id: Math.random().toString(36).substring(2, 10),
      title: programAd.name,
      status: 'Active',
      impressions: 0,
      clicks: 0,
      spent: 0,
      budget: parseFloat(programAd.price) || 100,
    };
    
    setCampaigns([newCampaign, ...campaigns]);
    setShowProgramAdForm(false);
    setProgramAd({ name: '', description: '', price: '' });
    showToast('Campaign created successfully');
  };

  const handleDownloadReport = () => {
    showToast('Report download started');
    setTimeout(() => {
      showToast('Report downloaded successfully');
    }, 1500);
  };

  if (!isB2BLoggedIn) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white flex flex-col items-center justify-center p-4 transition-colors">
        <div className="w-full max-w-md">
          <Link href="/" className="inline-flex items-center gap-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white mb-8 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Student App</span>
          </Link>
          
          <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-xl">
            <div className="w-16 h-16 bg-blue-50 dark:bg-blue-900/20 rounded-2xl flex items-center justify-center mb-6">
              <Building2 className="w-8 h-8 text-blue-600 dark:text-blue-400" />
            </div>
            
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Business Portal</h1>
            <p className="text-slate-500 dark:text-slate-400 mb-8">Sign in to manage your events, tickets, and promotions.</p>
            
            <form onSubmit={handleLogin} className="space-y-4">
              {loginError && (
                <div className="p-3 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 text-sm rounded-xl border border-red-100 dark:border-red-900/30">
                  {loginError}
                </div>
              )}
              
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Organization Email</label>
                <input 
                  type="email" 
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  className="w-full px-4 py-3 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                  placeholder="hello@sammakko.fi"
                />
              </div>
              
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300">Password</label>
                  <a href="#" className="text-sm font-medium text-blue-600 dark:text-blue-400 hover:underline">Forgot password?</a>
                </div>
                <div className="relative">
                  <input 
                    type="password" 
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full px-4 py-3 pl-10 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition-all" 
                    placeholder="••••••••"
                  />
                  <Lock className="w-4 h-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2" />
                </div>
              </div>
              
              <button 
                type="submit" 
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl font-bold transition-colors mt-2"
              >
                Sign In
              </button>
            </form>
            
            <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 text-center">
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Want to partner with Studify? <a href="#" className="font-medium text-blue-600 dark:text-blue-400 hover:underline">Contact Sales</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white transition-colors">
      {/* Header */}
      <header className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="p-2 -ml-2 text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors rounded-full hover:bg-slate-100 dark:hover:bg-slate-800">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div>
              <h1 className="text-xl font-bold text-blue-600 tracking-tight">Studify <span className="text-slate-900 dark:text-white">Business</span></h1>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/50 flex items-center justify-center text-blue-600 dark:text-blue-400 font-bold text-sm">
              SA
            </div>
            <span className="text-sm font-medium hidden sm:block">SAMMAKKO ry</span>
            <button 
              onClick={() => setIsB2BLoggedIn(false)}
              className="ml-4 text-sm font-medium text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white transition-colors"
            >
              Sign Out
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row gap-8">
        {/* Sidebar Nav */}
        <aside className="w-full md:w-64 shrink-0">
          <nav className="flex md:flex-col gap-2 overflow-x-auto pb-4 md:pb-0">
            <button 
              onClick={() => setActiveTab('dashboard')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-colors whitespace-nowrap ${activeTab === 'dashboard' ? 'bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
            >
              <BarChart3 className="w-5 h-5" />
              Dashboard
            </button>
            <button 
              onClick={() => setActiveTab('events')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-colors whitespace-nowrap ${activeTab === 'events' ? 'bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
            >
              <CalendarDays className="w-5 h-5" />
              Manage Events
            </button>
            <button 
              onClick={() => setActiveTab('checkin')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-colors whitespace-nowrap ${activeTab === 'checkin' ? 'bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
            >
              <ScanLine className="w-5 h-5" />
              Check-in
            </button>
            <button 
              onClick={() => setActiveTab('ads')}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl font-medium transition-colors whitespace-nowrap ${activeTab === 'ads' ? 'bg-blue-50 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'}`}
            >
              <Megaphone className="w-5 h-5" />
              Promotions & Ads
            </button>
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 min-w-0">
          {activeTab === 'dashboard' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Dashboard Overview</h2>
                <div className="flex gap-2">
                  <select className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2 text-sm font-medium outline-none focus:ring-2 focus:ring-blue-500">
                    <option>Last 7 Days</option>
                    <option>Last 30 Days</option>
                    <option>This Year</option>
                  </select>
                  <button onClick={handleDownloadReport} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors shadow-sm">
                    Download Report
                  </button>
                </div>
              </div>
              
              {/* Stats Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400">Total Revenue</h3>
                    <div className="w-10 h-10 rounded-full bg-emerald-50 dark:bg-emerald-900/20 flex items-center justify-center">
                      <DollarSign className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                    </div>
                  </div>
                  <p className="text-3xl font-bold text-slate-900 dark:text-white">€{events.reduce((sum, e) => sum + (e.price * (e.ticketsSold || 0)), 0).toFixed(2)}</p>
                  <p className="text-sm text-emerald-600 dark:text-emerald-400 mt-2 flex items-center gap-1 font-medium">
                    <TrendingUp className="w-4 h-4" /> +12.5% <span className="text-slate-400 font-normal ml-1">vs last week</span>
                  </p>
                </div>

                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400">Tickets Sold</h3>
                    <div className="w-10 h-10 rounded-full bg-blue-50 dark:bg-blue-900/20 flex items-center justify-center">
                      <Ticket className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                    </div>
                  </div>
                  <p className="text-3xl font-bold text-slate-900 dark:text-white">{events.reduce((sum, e) => sum + (e.ticketsSold || 0), 0)}</p>
                  <p className="text-sm text-emerald-600 dark:text-emerald-400 mt-2 flex items-center gap-1 font-medium">
                    <TrendingUp className="w-4 h-4" /> +5.2% <span className="text-slate-400 font-normal ml-1">vs last week</span>
                  </p>
                </div>

                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400">Event Views</h3>
                    <div className="w-10 h-10 rounded-full bg-purple-50 dark:bg-purple-900/20 flex items-center justify-center">
                      <Eye className="w-5 h-5 text-purple-600 dark:text-purple-400" />
                    </div>
                  </div>
                  <p className="text-3xl font-bold text-slate-900 dark:text-white">{events.reduce((sum, e) => sum + (e.views || 0), 0)}</p>
                  <p className="text-sm text-emerald-600 dark:text-emerald-400 mt-2 flex items-center gap-1 font-medium">
                    <TrendingUp className="w-4 h-4" /> +22.4% <span className="text-slate-400 font-normal ml-1">vs last week</span>
                  </p>
                </div>

                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400">Active Events</h3>
                    <div className="w-10 h-10 rounded-full bg-amber-50 dark:bg-amber-900/20 flex items-center justify-center">
                      <CalendarDays className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                    </div>
                  </div>
                  <p className="text-3xl font-bold text-slate-900 dark:text-white">{events.length}</p>
                  <p className="text-sm text-slate-500 dark:text-slate-400 mt-2 font-medium">Currently published</p>
                </div>
              </div>

              {/* Charts Section */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                  <h3 className="text-lg font-bold mb-6">Revenue & Ticket Sales (Last 7 Days)</h3>
                  <div className="h-72 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={revenueData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <defs>
                          <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#2563eb" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} dy={10} />
                        <YAxis yAxisId="left" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} tickFormatter={(value) => `€${value}`} />
                        <YAxis yAxisId="right" orientation="right" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                        <RechartsTooltip 
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)' }}
                          formatter={(value: any, name: any) => [name === 'revenue' ? `€${value}` : value, name === 'revenue' ? 'Revenue' : 'Tickets']}
                        />
                        <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', paddingTop: '20px' }} />
                        <Area yAxisId="left" type="monotone" dataKey="revenue" stroke="#2563eb" strokeWidth={3} fillOpacity={1} fill="url(#colorRevenue)" name="Revenue" />
                        <Line yAxisId="right" type="monotone" dataKey="tickets" stroke="#10b981" strokeWidth={3} dot={{ r: 4, strokeWidth: 2 }} name="Tickets Sold" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                  <h3 className="text-lg font-bold mb-6">Sales by Event</h3>
                  <div className="h-72 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={ticketSalesData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} dy={10} />
                        <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                        <RechartsTooltip 
                          cursor={{ fill: '#f1f5f9' }}
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)' }}
                        />
                        <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', paddingTop: '20px' }} />
                        <Bar dataKey="sold" stackId="a" fill="#3b82f6" radius={[0, 0, 4, 4]} name="Sold" />
                        <Bar dataKey="remaining" stackId="a" fill="#e2e8f0" radius={[4, 4, 0, 0]} name="Remaining" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'events' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <h2 className="text-2xl font-bold">Manage Events</h2>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="Search events..." 
                      value={eventSearchQuery}
                      onChange={(e) => setEventSearchQuery(e.target.value)}
                      className="pl-9 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none text-sm w-full sm:w-64 transition-all shadow-sm"
                    />
                  </div>
                  <button onClick={() => showToast('Filter applied')} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 p-2.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors shadow-sm">
                    <Filter className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => {
                      setEditingEventId(null);
                      setNewEvent({ title: '', date: '', time: '', location: '', price: '', image: '', description: '', category: '', capacity: '' });
                      setShowCreateEvent(true);
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-xl font-medium transition-colors flex items-center justify-center gap-2 shadow-sm whitespace-nowrap"
                  >
                    <Plus className="w-5 h-5" />
                    Create Event
                  </button>
                </div>
              </div>

              {showCreateEvent ? (
                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-bold">{editingEventId ? 'Edit Event' : 'New Event Details'}</h3>
                    <button onClick={() => setShowCreateEvent(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">Cancel</button>
                  </div>
                  <form onSubmit={handleCreateEvent} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Event Title</label>
                        <input required type="text" value={newEvent.title} onChange={e => setNewEvent({...newEvent, title: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none" placeholder="e.g. Back to School Party" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Category</label>
                        <select value={newEvent.category} onChange={e => setNewEvent({...newEvent, category: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none">
                          <option value="">Select Category</option>
                          <option value="Party">Party</option>
                          <option value="Sports">Sports</option>
                          <option value="Academic">Academic</option>
                          <option value="Culture">Culture</option>
                        </select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Date</label>
                        <input required type="date" value={newEvent.date} onChange={e => setNewEvent({...newEvent, date: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Time</label>
                        <input required type="time" value={newEvent.time} onChange={e => setNewEvent({...newEvent, time: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Location</label>
                      <input required type="text" value={newEvent.location} onChange={e => setNewEvent({...newEvent, location: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none" placeholder="e.g. Cabaret, Pori" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Description</label>
                      <textarea rows={3} value={newEvent.description} onChange={e => setNewEvent({...newEvent, description: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none" placeholder="Describe your event..." />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Ticket Price (€)</label>
                        <input required type="number" step="0.01" min="0" value={newEvent.price} onChange={e => setNewEvent({...newEvent, price: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none" placeholder="5.00" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Capacity</label>
                        <input type="number" min="1" value={newEvent.capacity} onChange={e => setNewEvent({...newEvent, capacity: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none" placeholder="e.g. 500" />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1.5">Cover Image URL</label>
                        <input type="url" value={newEvent.image} onChange={e => setNewEvent({...newEvent, image: e.target.value})} className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none" placeholder="https://..." />
                      </div>
                    </div>
                    <div className="pt-4 flex justify-end">
                      <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-xl font-medium transition-colors">
                        {editingEventId ? 'Save Changes' : 'Publish Event'}
                      </button>
                    </div>
                  </form>
                </div>
              ) : (
                <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm">
                      <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                        <tr>
                          <th className="px-6 py-4 font-medium">Event</th>
                          <th className="px-6 py-4 font-medium">Date & Time</th>
                          <th className="px-6 py-4 font-medium">Price</th>
                          <th className="px-6 py-4 font-medium">Tickets</th>
                          <th className="px-6 py-4 font-medium">Revenue</th>
                          <th className="px-6 py-4 font-medium">Views</th>
                          <th className="px-6 py-4 font-medium">Status</th>
                          <th className="px-6 py-4 font-medium text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                        {filteredEvents.map(event => (
                          <tr key={event.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors group">
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <div className="relative w-10 h-10 rounded-lg bg-slate-200 dark:bg-slate-800 overflow-hidden shrink-0">
                                  <Image src={event.image} alt={event.title} fill className="object-cover" referrerPolicy="no-referrer" />
                                </div>
                                <div>
                                  <div className="font-medium text-slate-900 dark:text-white">{event.title}</div>
                                  <div className="text-slate-500 dark:text-slate-400 text-xs mt-0.5">{event.location}</div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-slate-600 dark:text-slate-300">
                              <div className="text-sm">{event.date.split(' • ')[0]}</div>
                              <div className="text-xs text-slate-500">{event.date.split(' • ')[1]}</div>
                            </td>
                            <td className="px-6 py-4 text-slate-600 dark:text-slate-300 font-medium">€{event.price.toFixed(2)}</td>
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-2">
                                <div className="flex-1 h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden w-24">
                                  <div 
                                    className="h-full bg-blue-500 rounded-full" 
                                    style={{ width: `${Math.min(100, ((event.ticketsSold || 0) / (event.capacity || 100)) * 100)}%` }}
                                  />
                                </div>
                                <span className="text-xs font-medium text-slate-600 dark:text-slate-300">
                                  {event.capacity ? `${event.ticketsSold || 0}/${event.capacity}` : (event.ticketsSold || 0)}
                                </span>
                              </div>
                            </td>
                            <td className="px-6 py-4 text-slate-600 dark:text-slate-300 font-medium text-emerald-600 dark:text-emerald-400">€{((event.ticketsSold || 0) * event.price).toFixed(2)}</td>
                            <td className="px-6 py-4 text-slate-600 dark:text-slate-300">{event.views || 0}</td>
                            <td className="px-6 py-4">
                              <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800/50">
                                Published
                              </span>
                            </td>
                            <td className="px-6 py-4 text-right">
                              <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <button onClick={() => handleEditEvent(event)} className="p-2 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/20" title="Edit">
                                  <Edit className="w-4 h-4" />
                                </button>
                                <button onClick={() => handleDeleteEvent(event.id)} className="p-2 text-slate-400 hover:text-red-600 dark:hover:text-red-400 transition-colors rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20" title="Delete">
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                        {filteredEvents.length === 0 && (
                          <tr>
                            <td colSpan={8} className="px-6 py-12 text-center text-slate-500 dark:text-slate-400">
                              <div className="flex flex-col items-center justify-center">
                                <CalendarDays className="w-12 h-12 text-slate-300 dark:text-slate-700 mb-3" />
                                <p className="text-lg font-medium text-slate-900 dark:text-white mb-1">No events found</p>
                                <p className="text-sm">Try adjusting your search or create a new event.</p>
                              </div>
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'checkin' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <h2 className="text-2xl font-bold">Ticket Scanner & Check-in</h2>
                <div className="flex items-center gap-4 bg-white dark:bg-slate-900 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
                  <div className="text-sm">
                    <span className="text-slate-500 dark:text-slate-400">Checked in: </span>
                    <span className="font-bold text-slate-900 dark:text-white">{checkedInCount}</span>
                    <span className="text-slate-400 mx-1">/</span>
                    <span className="font-medium text-slate-600 dark:text-slate-300">{purchasedTickets.length}</span>
                  </div>
                  <div className="w-24 h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-emerald-500 rounded-full transition-all duration-500"
                      style={{ width: `${purchasedTickets.length > 0 ? (checkedInCount / purchasedTickets.length) * 100 : 0}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1">
                  <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm text-center sticky top-24">
                    <div className="w-full aspect-square bg-slate-100 dark:bg-slate-800 rounded-xl mb-6 flex flex-col items-center justify-center border-2 border-dashed border-slate-300 dark:border-slate-700 relative overflow-hidden group cursor-pointer hover:border-blue-500 transition-colors">
                      <div className="absolute inset-0 bg-blue-500/5 group-hover:bg-blue-500/10 transition-colors" />
                      <ScanLine className="w-12 h-12 text-slate-400 group-hover:text-blue-500 transition-colors mb-3" />
                      <p className="text-sm text-slate-500 dark:text-slate-400 font-medium">Click to activate camera</p>
                      <div className="absolute top-1/2 left-0 w-full h-0.5 bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.8)] animate-[scan_2s_ease-in-out_infinite] opacity-50 group-hover:opacity-100" />
                    </div>
                    
                    <div className="relative mb-4">
                      <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-slate-200 dark:border-slate-800"></div>
                      </div>
                      <div className="relative flex justify-center text-sm">
                        <span className="px-2 bg-white dark:bg-slate-900 text-slate-500">or enter manually</span>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        value={ticketVerificationId}
                        onChange={(e) => setTicketVerificationId(e.target.value)}
                        placeholder="Ticket ID (e.g. TICKET-XYZ)" 
                        className="flex-1 px-4 py-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none text-sm font-mono uppercase"
                      />
                      <button onClick={handleVerifyTicket} className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-4 py-3 rounded-xl font-bold transition-transform active:scale-95 shadow-sm">
                        Verify
                      </button>
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-2">
                  <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden h-full flex flex-col min-h-[500px]">
                    <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-50 dark:bg-slate-800/50">
                      <h3 className="font-bold text-lg">Ticket List</h3>
                      <div className="relative">
                        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                          type="text" 
                          placeholder="Search tickets..." 
                          value={ticketSearchQuery}
                          onChange={(e) => setTicketSearchQuery(e.target.value)}
                          className="pl-9 pr-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-2 focus:ring-blue-600 outline-none text-sm w-full sm:w-64 transition-all shadow-sm"
                        />
                      </div>
                    </div>
                    <div className="overflow-y-auto flex-1 p-0">
                      {filteredTickets.length === 0 ? (
                        <div className="p-12 text-center text-slate-500 dark:text-slate-400 flex flex-col items-center justify-center h-full">
                          <Ticket className="w-12 h-12 text-slate-300 dark:text-slate-700 mb-3" />
                          <p className="text-lg font-medium text-slate-900 dark:text-white mb-1">No tickets found</p>
                          <p className="text-sm">Try adjusting your search query.</p>
                        </div>
                      ) : (
                        <ul className="divide-y divide-slate-100 dark:divide-slate-800">
                          {filteredTickets.slice().reverse().map(ticket => (
                            <li key={ticket.id} className="p-4 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors group">
                              <div className="flex items-center gap-4">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${ticket.status === 'used' ? 'bg-slate-100 text-slate-400 dark:bg-slate-800' : 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400'}`}>
                                  <Ticket className="w-5 h-5" />
                                </div>
                                <div>
                                  <p className="font-bold text-slate-900 dark:text-white">{ticket.event.title}</p>
                                  <div className="flex items-center gap-2 mt-0.5">
                                    <p className="text-sm text-slate-500 dark:text-slate-400 font-mono bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">{ticket.qrCode}</p>
                                    <span className="text-xs text-slate-400">•</span>
                                    <p className="text-xs text-slate-500">{new Date(ticket.purchaseDate).toLocaleDateString()}</p>
                                  </div>
                                </div>
                              </div>
                              <div>
                                {ticket.status === 'used' ? (
                                  <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                                    <CheckCircle2 className="w-4 h-4" /> Checked In
                                  </span>
                                ) : (
                                  <button 
                                    onClick={() => handleCheckIn(ticket.id)}
                                    className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg text-sm font-bold transition-all shadow-sm active:scale-95 flex items-center gap-2"
                                  >
                                    <ScanLine className="w-4 h-4" />
                                    Check In
                                  </button>
                                )}
                              </div>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'ads' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <h2 className="text-2xl font-bold">Promotions & Ads</h2>
                <button onClick={() => setShowProgramAdForm(true)} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-xl font-medium transition-colors flex items-center justify-center gap-2 shadow-sm">
                  <Plus className="w-5 h-5" />
                  Create Campaign
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm col-span-1 lg:col-span-3 flex flex-col sm:flex-row items-center justify-between gap-6 bg-gradient-to-r from-blue-50 to-indigo-50 dark:from-blue-900/10 dark:to-indigo-900/10">
                  <div className="flex items-center gap-6">
                    <div className="w-16 h-16 bg-white dark:bg-slate-800 rounded-full flex items-center justify-center shadow-sm shrink-0">
                      <Megaphone className="w-8 h-8 text-blue-600 dark:text-blue-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-1 text-slate-900 dark:text-white">Reach more students</h3>
                      <p className="text-slate-600 dark:text-slate-400 max-w-xl">
                        Promote your events, student discounts, or job openings directly to thousands of active students in the Studify app.
                      </p>
                    </div>
                  </div>
                  <Link href="/b2b/advertise" className="bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-6 py-3 rounded-xl font-bold transition-transform active:scale-95 shadow-md whitespace-nowrap shrink-0">
                    Start Advertising
                  </Link>
                </div>
              </div>

              {showProgramAdForm && (
                <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm mb-8">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-bold">New Campaign</h3>
                    <button onClick={() => setShowProgramAdForm(false)} className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">Cancel</button>
                  </div>
                  <form onSubmit={handleCreateProgramAd} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Campaign Name</label>
                      <input 
                        type="text" 
                        required
                        value={programAd.name}
                        onChange={e => setProgramAd({...programAd, name: e.target.value})}
                        className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition-all"
                        placeholder="e.g. Summer Coding Bootcamp"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Description</label>
                      <textarea 
                        required
                        rows={3}
                        value={programAd.description}
                        onChange={e => setProgramAd({...programAd, description: e.target.value})}
                        className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition-all resize-none"
                        placeholder="Describe your program..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">Budget / Price (€)</label>
                      <input 
                        type="number" 
                        required
                        min="1"
                        step="0.01"
                        value={programAd.price}
                        onChange={e => setProgramAd({...programAd, price: e.target.value})}
                        className="w-full px-4 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-blue-600 outline-none transition-all"
                        placeholder="100.00"
                      />
                    </div>
                    <div className="flex justify-end gap-3 pt-4">
                      <button type="button" onClick={() => setShowProgramAdForm(false)} className="px-5 py-2.5 text-slate-600 dark:text-slate-400 font-medium hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-colors">
                        Cancel
                      </button>
                      <button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-medium transition-colors shadow-sm">
                        Start Campaign
                      </button>
                    </div>
                  </form>
                </div>
              )}

              <h3 className="text-lg font-bold mb-4">Active Campaigns</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {campaigns.map(campaign => (
                  <div key={campaign.id} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col">
                    <div className="p-5 border-b border-slate-100 dark:border-slate-800 flex items-start justify-between">
                      <div>
                        <h4 className="font-bold text-slate-900 dark:text-white mb-1">{campaign.title}</h4>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-bold ${
                          campaign.status === 'Active' 
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400' 
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400'
                        }`}>
                          {campaign.status}
                        </span>
                      </div>
                      <button onClick={() => handleDeleteCampaign(campaign.id)} className="text-red-400 hover:text-red-600 dark:hover:text-red-300">
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                    <div className="p-5 flex-1">
                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 font-medium uppercase tracking-wider mb-1">Impressions</p>
                          <p className="text-xl font-bold text-slate-900 dark:text-white">{campaign.impressions.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-xs text-slate-500 dark:text-slate-400 font-medium uppercase tracking-wider mb-1">Clicks</p>
                          <p className="text-xl font-bold text-slate-900 dark:text-white">{campaign.clicks.toLocaleString()}</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-500 dark:text-slate-400">Budget Spent</span>
                          <span className="font-medium text-slate-900 dark:text-white">€{campaign.spent.toFixed(2)} / €{campaign.budget.toFixed(2)}</span>
                        </div>
                        <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full ${campaign.spent / campaign.budget > 0.9 ? 'bg-red-500' : 'bg-blue-500'}`}
                            style={{ width: `${(campaign.spent / campaign.budget) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex justify-between items-center">
                      <span className="text-sm font-medium text-slate-600 dark:text-slate-400">
                        CTR: {((campaign.clicks / campaign.impressions) * 100).toFixed(1)}%
                      </span>
                      <button onClick={() => handleToggleCampaignStatus(campaign.id)} className="flex items-center gap-1.5 text-sm font-bold text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors">
                        {campaign.status === 'Active' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                        {campaign.status === 'Active' ? 'Pause' : 'Resume'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
