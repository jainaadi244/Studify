'use client';

import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, Zap, Star, Crown, Loader2, Lock } from 'lucide-react';
import Link from 'next/link';
import { useApp } from '@/lib/AppContext';
import { motion, AnimatePresence } from 'motion/react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import { StripePaymentForm } from '@/components/StripePaymentForm';

const stripePromise = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY 
  ? loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY) 
  : null;

const TIERS = [
  {
    id: 'basic',
    name: 'Basic',
    price: 50,
    icon: Zap,
    color: 'text-blue-600 dark:text-blue-400',
    bgColor: 'bg-blue-50 dark:bg-blue-900/20',
    borderColor: 'border-blue-200 dark:border-blue-800',
    description: 'Perfect for small events looking for a quick visibility boost.',
    features: [
      'Standard placement in student feed',
      'Targeted to local universities',
      'Basic analytics dashboard',
      '~10% expected sales spike'
    ],
    buttonText: 'Start Basic'
  },
  {
    id: 'gold',
    name: 'Gold',
    price: 150,
    icon: Star,
    color: 'text-amber-500',
    bgColor: 'bg-amber-50 dark:bg-amber-900/20',
    borderColor: 'border-amber-200 dark:border-amber-800',
    description: 'Our most popular tier for maximizing event attendance.',
    features: [
      'Priority placement in student feed',
      '1 Push notification to target audience',
      'Advanced analytics & demographics',
      'Featured in "Top Picks" section',
      '~25% expected sales spike'
    ],
    buttonText: 'Start Gold',
    popular: true
  },
  {
    id: 'platinum',
    name: 'Platinum',
    price: 300,
    icon: Crown,
    color: 'text-purple-600 dark:text-purple-400',
    bgColor: 'bg-purple-50 dark:bg-purple-900/20',
    borderColor: 'border-purple-200 dark:border-purple-800',
    description: 'Maximum exposure for major events and brand campaigns.',
    features: [
      'Premium banner placement at top of app',
      '3 Push notifications to target audience',
      'Dedicated email blast to student list',
      'Custom branding options',
      'Dedicated account manager',
      '~50% expected sales spike'
    ],
    buttonText: 'Start Platinum'
  }
];

export default function AdvertisePage() {
  const { showToast } = useApp();
  const [selectedTier, setSelectedTier] = useState<string | null>(null);
  const [checkoutStep, setCheckoutStep] = useState<'selection' | 'confirm' | 'payment' | 'processing' | 'success'>('selection');
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [isFetchingSecret, setIsFetchingSecret] = useState(false);

  const handleSelectTier = (tierId: string) => {
    setSelectedTier(tierId);
    setCheckoutStep('confirm');
  };

  const handleContinueToPayment = async () => {
    if (!selectedTierData) return;
    
    setIsFetchingSecret(true);
    try {
      const response = await fetch('/api/create-payment-intent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: selectedTierData.price }),
      });
      const data = await response.json();
      
      if (response.ok && data.clientSecret) {
        setClientSecret(data.clientSecret);
        setCheckoutStep('payment');
      } else {
        console.error('Failed to create payment intent:', data.error);
        setCheckoutStep('payment');
      }
    } catch (e) {
      console.error(e);
      setCheckoutStep('payment');
    } finally {
      setIsFetchingSecret(false);
    }
  };

  const handleCheckout = () => {
    setCheckoutStep('processing');
    
    // Simulate payment processing
    setTimeout(() => {
      setCheckoutStep('success');
      showToast('Advertising program activated successfully!');
    }, 2000);
  };

  const selectedTierData = TIERS.find(t => t.id === selectedTier);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 font-sans text-slate-900 dark:text-white pb-20">
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 sticky top-0 z-30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/b2b" className="p-2 -ml-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <h1 className="text-xl font-bold">Advertising Programs</h1>
          </div>
        </div>
      </div>

      <main className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <AnimatePresence mode="wait">
          {checkoutStep === 'selection' && (
            <motion.div 
              key="selection"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              <div className="text-center max-w-3xl mx-auto">
                <h2 className="text-4xl font-black tracking-tight mb-4">Supercharge Your Reach</h2>
                <p className="text-xl text-slate-600 dark:text-slate-400">
                  Choose the right advertising tier to get your events and promotions in front of thousands of active students.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {TIERS.map((tier) => (
                  <div 
                    key={tier.id}
                    className={`relative bg-white dark:bg-slate-900 rounded-3xl border-2 ${tier.popular ? tier.borderColor : 'border-slate-200 dark:border-slate-800'} p-8 shadow-sm flex flex-col`}
                  >
                    {tier.popular && (
                      <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-amber-500 text-white px-4 py-1 rounded-full text-sm font-bold tracking-wide uppercase">
                        Most Popular
                      </div>
                    )}
                    
                    <div className={`w-14 h-14 ${tier.bgColor} rounded-2xl flex items-center justify-center mb-6`}>
                      <tier.icon className={`w-7 h-7 ${tier.color}`} />
                    </div>
                    
                    <h3 className="text-2xl font-bold mb-2">{tier.name}</h3>
                    <p className="text-slate-500 dark:text-slate-400 mb-6 h-12">{tier.description}</p>
                    
                    <div className="mb-8">
                      <span className="text-4xl font-black">€{tier.price}</span>
                      <span className="text-slate-500 dark:text-slate-400 font-medium">/month</span>
                    </div>
                    
                    <ul className="space-y-4 mb-8 flex-1">
                      {tier.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-3">
                          <CheckCircle2 className={`w-5 h-5 shrink-0 ${tier.color}`} />
                          <span className="text-slate-700 dark:text-slate-300 font-medium">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <button 
                      onClick={() => handleSelectTier(tier.id)}
                      className={`w-full py-4 rounded-xl font-bold text-lg transition-transform active:scale-95 ${
                        tier.popular 
                          ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-md' 
                          : 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-100'
                      }`}
                    >
                      {tier.buttonText}
                    </button>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {checkoutStep === 'confirm' && selectedTierData && (
            <motion.div 
              key="confirm"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-md mx-auto bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-8 shadow-sm"
            >
              <div className="flex items-center gap-4 mb-8">
                <button onClick={() => setCheckoutStep('selection')} className="p-2 -ml-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <h3 className="text-2xl font-bold">Confirm Purchase</h3>
              </div>

              <div className={`p-6 rounded-2xl ${selectedTierData.bgColor} border ${selectedTierData.borderColor} mb-8`}>
                <div className="flex items-center gap-4 mb-4">
                  <div className={`w-12 h-12 bg-white dark:bg-slate-800 rounded-xl flex items-center justify-center shadow-sm shrink-0`}>
                    <selectedTierData.icon className={`w-6 h-6 ${selectedTierData.color}`} />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold">{selectedTierData.name} Tier</h4>
                    <p className="text-sm text-slate-500 dark:text-slate-400">Monthly Subscription</p>
                  </div>
                </div>
                
                <div className="flex justify-between items-end pt-4 border-t border-slate-200 dark:border-slate-700/50">
                  <span className="font-medium text-slate-700 dark:text-slate-300">Total Due Today</span>
                  <span className="text-3xl font-black">€{selectedTierData.price.toFixed(2)}</span>
                </div>
              </div>

              <div className="space-y-4">
                <button 
                  onClick={handleContinueToPayment}
                  disabled={isFetchingSecret}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-lg flex items-center justify-center gap-2 transition-transform active:scale-95 shadow-sm disabled:opacity-50"
                >
                  {isFetchingSecret ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Continue to Payment'}
                </button>
                <p className="text-center text-xs text-slate-500 dark:text-slate-400">
                  By confirming, you agree to our Advertising Terms of Service. Your subscription will renew automatically.
                </p>
              </div>
            </motion.div>
          )}

          {checkoutStep === 'payment' && selectedTierData && (
            <motion.div 
              key="payment"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="max-w-md mx-auto bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden"
            >
              <div className="p-6 border-b border-slate-200 dark:border-slate-800 flex items-center gap-4">
                <button onClick={() => setCheckoutStep('confirm')} className="p-2 -ml-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <h3 className="text-xl font-bold">Payment Details</h3>
              </div>
              
              {clientSecret && stripePromise ? (
                <Elements stripe={stripePromise} options={{ clientSecret, appearance: { theme: 'stripe' } }}>
                  <StripePaymentForm amount={selectedTierData.price} onSuccess={handleCheckout} />
                </Elements>
              ) : (
                <div className="flex flex-col h-full">
                  <div className="p-6 bg-slate-50 dark:bg-slate-950/50 flex-grow">
                    <div className="flex justify-between items-center mb-6">
                      <span className="text-slate-500 dark:text-slate-400 font-medium">Total to pay</span>
                      <span className="font-bold text-2xl text-slate-900 dark:text-white">€{selectedTierData.price.toFixed(2)}</span>
                    </div>
                    <div className="bg-amber-50 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300 p-4 rounded-xl text-sm mb-6 border border-amber-200 dark:border-amber-800/50">
                      <p className="font-bold mb-1">Test Mode Active</p>
                      <p>Stripe keys are not configured. This is a simulated checkout flow.</p>
                    </div>
                  </div>
                  <div className="p-6 pt-4 bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800">
                    <button
                      onClick={handleCheckout}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition-all active:scale-95 shadow-sm"
                    >
                      <Lock className="w-4 h-4" />
                      Simulate Payment
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {checkoutStep === 'processing' && (
            <motion.div 
              key="processing"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-md mx-auto bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-12 text-center shadow-sm"
            >
              <div className="w-24 h-24 bg-blue-50 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-8">
                <Loader2 className="w-12 h-12 text-blue-600 dark:text-blue-400 animate-spin" />
              </div>
              <h3 className="text-2xl font-bold mb-2">Processing Payment</h3>
              <p className="text-slate-500 dark:text-slate-400 mb-6">Setting up your {selectedTierData?.name} advertising program...</p>
              
              <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-4 flex items-center justify-center gap-2 text-sm text-slate-500 dark:text-slate-400">
                <Lock className="w-4 h-4" />
                Secure simulated checkout
              </div>
            </motion.div>
          )}

          {checkoutStep === 'success' && (
            <motion.div 
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-md mx-auto bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-12 text-center shadow-sm"
            >
              <div className="w-24 h-24 bg-emerald-50 dark:bg-emerald-900/20 rounded-full flex items-center justify-center mx-auto mb-8">
                <CheckCircle2 className="w-12 h-12 text-emerald-500" />
              </div>
              <h3 className="text-2xl font-bold mb-2">You&apos;re All Set!</h3>
              <p className="text-slate-500 dark:text-slate-400 mb-8">
                Your {selectedTierData?.name} advertising program is now active. You&apos;ll start seeing increased visibility in the student app shortly.
              </p>
              
              <Link 
                href="/b2b"
                className="block w-full bg-blue-600 hover:bg-blue-700 text-white py-4 rounded-xl font-bold text-lg transition-transform active:scale-95 shadow-sm"
              >
                Return to Dashboard
              </Link>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
